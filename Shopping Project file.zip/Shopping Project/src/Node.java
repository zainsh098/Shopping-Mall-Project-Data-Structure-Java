public class Node {

    String name;
    Node next;
    int  ID;
    String proName;
    double proprice;
    int quantity;


}
